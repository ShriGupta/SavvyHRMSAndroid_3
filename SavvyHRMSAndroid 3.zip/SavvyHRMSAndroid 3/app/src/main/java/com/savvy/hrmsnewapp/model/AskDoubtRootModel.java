package com.savvy.hrmsnewapp.model;

/**
 * Created by Hari Om on 8/14/2016.
 */
public class AskDoubtRootModel {

    public AskDoubtModel getJson_data() {
        return json_data;
    }

    public void setJson_data(AskDoubtModel json_data) {
        this.json_data = json_data;
    }

    public AskDoubtModel json_data;
}
