package com.savvy.hrmsnewapp.model;

/**
 * Created by am00347646 on 28-07-2016.
 */
public class DashboardSubjectModel {

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSubject_id() {
        return subject_id;
    }

    public void setSubject_id(String subject_id) {
        this.subject_id = subject_id;
    }

    public String subject;
    public String subject_id;
}
