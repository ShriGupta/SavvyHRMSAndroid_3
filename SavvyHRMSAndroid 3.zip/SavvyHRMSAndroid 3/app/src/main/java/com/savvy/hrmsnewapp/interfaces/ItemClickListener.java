package com.savvy.hrmsnewapp.interfaces;

public interface ItemClickListener {
    void onClickItem(int position, String data);
}
