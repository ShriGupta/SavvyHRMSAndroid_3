
package com.savvy.hrmsnewapp.managers;

import java.util.ArrayList;

public class ParseManager {

    public static <T> ArrayList<T> parseServerResponse(String response, Object type) {
        return null;
    }

	/*public static <T> Object parseServerResponse(String response, Class<T> type){

		Gson gson = new Gson();

		return gson.fromJson(response, type);

	}*/

	/*public static ParseModel parseServerResponse(String response){
		ParseModel parseModelObj;


*//**
     * parsing code here
     *
     *//*


		parseModelObj=new ParseModel();

		parseModelObj.id=1;
		parseModelObj.description=response;


		return parseModelObj;

	}*/
}

