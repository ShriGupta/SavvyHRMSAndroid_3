package com.savvy.hrmsnewapp.model;

/**
 * Created by Hari Om on 7/28/2016.
 */
public class AbsentDateslistModel {


    public String getDate_id() {
        return date_id;
    }

    public void setDate_id(String date_id) {
        this.date_id = date_id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String date_id;
    public String date;
    public String day;


}
