package com.savvy.hrmsnewapp.model;

/**
 * Created by Hari Om on 7/29/2016.
 */
public class AttendanceDetailRootModel {

    public AttendanceDetailModel getJson_data() {
        return json_data;
    }

    public void setJson_data(AttendanceDetailModel json_data) {
        this.json_data = json_data;
    }

    AttendanceDetailModel  json_data;
}
