package com.savvy.hrmsnewapp.helper;

public interface OnFileUploadListener {
    void onFileUploadSuccess(String result);
}
