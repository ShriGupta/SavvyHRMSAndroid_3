package com.savvy.hrmsnewapp.model;

/**
 * Created by AM00347646 on 09-08-2016.
 */
public class NoticeRootModel {

    public NoticesModel getJson_data() {
        return json_data;
    }

    public void setJson_data(NoticesModel json_data) {
        this.json_data = json_data;
    }

    public NoticesModel json_data;
}
