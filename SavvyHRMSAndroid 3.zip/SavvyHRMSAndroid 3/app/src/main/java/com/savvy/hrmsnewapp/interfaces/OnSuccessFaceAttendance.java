package com.savvy.hrmsnewapp.interfaces;

public interface OnSuccessFaceAttendance {
    public void loadData();
}
