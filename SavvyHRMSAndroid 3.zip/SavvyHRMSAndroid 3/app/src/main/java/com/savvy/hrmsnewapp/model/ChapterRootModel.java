package com.savvy.hrmsnewapp.model;

/**
 * Created by Hari Om on 8/15/2016.
 */
public class ChapterRootModel {
    public ChapterModel getJson_data() {
        return json_data;
    }

    public void setJson_data(ChapterModel json_data) {
        this.json_data = json_data;
    }

    public ChapterModel json_data;
}
