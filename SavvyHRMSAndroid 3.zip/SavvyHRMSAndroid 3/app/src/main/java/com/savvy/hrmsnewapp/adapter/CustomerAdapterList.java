package com.savvy.hrmsnewapp.adapter;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.savvy.hrmsnewapp.R;

public class CustomerAdapterList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_adapter_list);
    }
}
