package com.savvy.hrmsnewapp.model;

/**
 * Created by Amulya on 7/27/2016.
 */
public class DashboardRootModel {

    public DashboardModel getJson_data() {
        return json_data;
    }

    public void setJson_data(DashboardModel json_data) {
        this.json_data = json_data;
    }

    public DashboardModel json_data;
}
