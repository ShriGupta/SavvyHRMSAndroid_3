package com.savvy.hrmsnewapp.interfaces;

public interface OnOptionSelected {
    public void onOptionSelected(String quesId, String quesName, String ansId, String ansName, String correctAnsId, String correcrAnsName);
}
