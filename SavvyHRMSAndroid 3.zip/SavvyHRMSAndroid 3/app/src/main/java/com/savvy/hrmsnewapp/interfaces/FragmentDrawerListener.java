package com.savvy.hrmsnewapp.interfaces;

import android.view.View;

public interface FragmentDrawerListener {
    void onDrawerItemSelected(View view, String position, String privillageName);
}
