package com.savvy.hrmsnewapp.interfaces;

public interface OnTeamButtonClickListener {
    void onClick(int postion,String empCode,String attandanceDate,String punMode);
}
