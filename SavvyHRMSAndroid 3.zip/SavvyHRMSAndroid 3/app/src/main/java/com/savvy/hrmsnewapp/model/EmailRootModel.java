package com.savvy.hrmsnewapp.model;

/**
 * Created by Hari Om on 8/12/2016.
 */
public class EmailRootModel  {


    public EmailModel getJson_data() {
        return json_data;
    }

    public void setJson_data(EmailModel json_data) {
        this.json_data = json_data;
    }

    public EmailModel json_data;

}
