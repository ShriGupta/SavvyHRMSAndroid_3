package com.savvy.hrmsnewapp.model;

/**
 * Created by Amulya on 8/13/2016.
 */
public class AcademicsRootModel {

    public AcademicsModel getJson_data() {
        return json_data;
    }

    public void setJson_data(AcademicsModel json_data) {
        this.json_data = json_data;
    }

    public AcademicsModel json_data;
}
