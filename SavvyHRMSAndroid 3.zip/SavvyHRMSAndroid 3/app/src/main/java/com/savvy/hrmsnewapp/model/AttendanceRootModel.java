package com.savvy.hrmsnewapp.model;

/**
 * Created by Hari Om on 7/27/2016.
 */
public class AttendanceRootModel {


    public AttendanceModel getJson_data() {
        return json_data;
    }

    public void setJson_data(AttendanceModel json_data) {
        this.json_data = json_data;
    }

    public AttendanceModel json_data;
}
