package com.savvy.hrmsnewapp.interfaces;

public interface FilePathListener {
    public void callback( String result);
}
