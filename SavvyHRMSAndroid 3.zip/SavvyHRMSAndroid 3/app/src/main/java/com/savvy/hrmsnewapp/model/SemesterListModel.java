package com.savvy.hrmsnewapp.model;

/**
 * Created by Amulya on 8/13/2016.
 */
public class SemesterListModel {

    public String getSem_id() {
        return sem_id;
    }

    public void setSem_id(String sem_id) {
        this.sem_id = sem_id;
    }

    public String getSem_name() {
        return sem_name;
    }

    public void setSem_name(String sem_name) {
        this.sem_name = sem_name;
    }

    public String sem_id;
    public String sem_name;
}
