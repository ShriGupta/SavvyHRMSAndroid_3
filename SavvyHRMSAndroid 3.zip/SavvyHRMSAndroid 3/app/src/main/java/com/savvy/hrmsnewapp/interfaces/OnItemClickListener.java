package com.savvy.hrmsnewapp.interfaces;

interface OnButtonClickListener {
    void onClick(boolean b);
}
