package com.savvy.hrmsnewapp.model;

/**
 * Created by Hari Om on 8/9/2016.
 */
public class CalenderDetailDataModel {


    public String getFaculty_id() {
        return faculty_id;
    }

    public void setFaculty_id(String faculty_id) {
        this.faculty_id = faculty_id;
    }

    public String getFaculty_name() {
        return faculty_name;
    }

    public void setFaculty_name(String faculty_name) {
        this.faculty_name = faculty_name;
    }

    public String getFaculty_subject() {
        return faculty_subject;
    }

    public void setFaculty_subject(String faculty_subject) {
        this.faculty_subject = faculty_subject;
    }

    public String getFaculty_mobile() {
        return faculty_mobile;
    }

    public void setFaculty_mobile(String faculty_mobile) {
        this.faculty_mobile = faculty_mobile;
    }

    public String getFaculty_emailid() {
        return faculty_emailid;
    }

    public void setFaculty_emailid(String faculty_emailid) {
        this.faculty_emailid = faculty_emailid;
    }

    public String getFaculty_batch() {
        return faculty_batch;
    }

    public void setFaculty_batch(String faculty_batch) {
        this.faculty_batch = faculty_batch;
    }

    public String getFaculty_photo() {
        return faculty_photo;
    }

    public void setFaculty_photo(String faculty_photo) {
        this.faculty_photo = faculty_photo;
    }

    public String getLecture_starttime() {
        return lecture_starttime;
    }

    public void setLecture_starttime(String lecture_starttime) {
        this.lecture_starttime = lecture_starttime;
    }

    public String getLecture_endtime() {
        return lecture_endtime;
    }

    public void setLecture_endtime(String lecture_endtime) {
        this.lecture_endtime = lecture_endtime;
    }

    public String getLecture_date() {
        return lecture_date;
    }

    public void setLecture_date(String lecture_date) {
        this.lecture_date = lecture_date;
    }

    public String getLecture_day() {
        return lecture_day;
    }

    public void setLecture_day(String lecture_day) {
        this.lecture_day = lecture_day;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getChapter() {
        return chapter;
    }

    public void setChapter(String chapter) {
        this.chapter = chapter;
    }

    public String getFaculty_timing() {
        return faculty_timing;
    }

    public void setFaculty_timing(String faculty_timing) {
        this.faculty_timing = faculty_timing;
    }

    public String faculty_id;
    public String faculty_name;
    public String faculty_subject;
    public String faculty_mobile;
    public String faculty_emailid;
    public String faculty_batch;
    public String faculty_photo;

    public String lecture_starttime;
    public String lecture_endtime;
    public String lecture_date;
    public String lecture_day;
    public String address;
    public String chapter;
    public String faculty_timing;
}
