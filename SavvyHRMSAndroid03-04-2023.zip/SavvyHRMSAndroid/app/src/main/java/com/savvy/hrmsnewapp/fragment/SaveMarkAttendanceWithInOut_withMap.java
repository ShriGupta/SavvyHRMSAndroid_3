package com.savvy.hrmsnewapp.fragment;


import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.snackbar.Snackbar;
import com.savvy.hrmsnewapp.R;
import com.savvy.hrmsnewapp.rahul.AddressDetails;
import com.savvy.hrmsnewapp.service.LocationService;
import com.savvy.hrmsnewapp.utils.Constants;
import com.savvy.hrmsnewapp.utils.ErrorConstants;
import com.savvy.hrmsnewapp.utils.LogMaintainance;
import com.savvy.hrmsnewapp.utils.Utilities;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static android.content.ContentValues.TAG;

/**
 * A simple {@link Fragment} subclass.
 */
public class SaveMarkAttendanceWithInOut_withMap extends BaseFragment implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, LocationListener, View.OnClickListener {

    TextView tvHeader, tvAddress;
    public static final String MY_PREFS_NAME = "MyPrefsFile";
    SharedPreferences shared;
    Button btn_punchOut, btn_punchIn;
    EditText edt_messagefeedback;
    private GoogleApiClient googleApiClient;

    private static final int LOCATION_REQUEST_CODE = 101;
    final static int REQUEST_LOCATION = 199;

    String token = "", empoyeeId = "", username = "";

    private Context mContext;
    private GoogleMap mMap;
    private Snackbar snackbar;
    private Location location;
    String locationAddress = "";

    private final static int CONNECTION_FAILURE_RESOLUTION_REQUEST = 9000;


    private LocationRequest mLocationRequest;
    private String title;
    public AddressDetails addressDetails;

    public SaveMarkAttendanceWithInOut_withMap() {
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = getActivity();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e("MarkAttendance", "onCreate");
        coordinatorLayout = getActivity().findViewById(R.id.coordinatorLayout);

        shared = getActivity().getSharedPreferences(MY_PREFS_NAME, Context.MODE_PRIVATE);
        token = (shared.getString("Token", ""));
        empoyeeId = (shared.getString("EmpoyeeId", ""));
        username = (shared.getString("UserName", ""));

        title = (shared.getString("Title", ""));


    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_save_mark_attendance_with_in_out_with_map, container, false);
        Log.e("MarkAttendance", "onCreateView");

        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        View rootView = getView();
        Log.e("MarkAttendance", "onActivityCreated");
        setMap();
        coordinatorLayout = getActivity().findViewById(R.id.coordinatorLayout);

        btn_punchIn = rootView.findViewById(R.id.btn_punchIn);
        btn_punchOut = rootView.findViewById(R.id.btn_punchOut);


        btn_punchOut.setOnClickListener(this);
        btn_punchIn.setOnClickListener(this);


        edt_messagefeedback = rootView.findViewById(R.id.edt_messagefeedback);
        tvHeader = rootView.findViewById(R.id.tvHeader);
        tvAddress = rootView.findViewById(R.id.tvAddress);
        edt_messagefeedback.setImeOptions(EditorInfo.IME_ACTION_DONE);
        edt_messagefeedback.setRawInputType(InputType.TYPE_CLASS_TEXT);
        tvAddress.setText("");

        Log.e("Title Value", title);
        if (title.contains("Customer")) {
            tvHeader.setText("Customer Name/Remarks");
            edt_messagefeedback.setHint("Customer Name/Remarks");

        } else {
            tvHeader.setText("Comment");
            edt_messagefeedback.setHint("Comment");
        }
    }

    private void setMap() {
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);

        //Instantiating the GoogleApiClient
        googleApiClient = new GoogleApiClient.Builder(mContext)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();


        setLocationResult();


    }

    private void setLocationResult() {
        // Create the LocationRequest object
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(10 * 1000)        // 10 seconds, in milliseconds
                .setFastestInterval(1 * 1000); // 1 second, in milliseconds

        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(30 * 1000);
        locationRequest.setFastestInterval(5 * 1000);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                .addLocationRequest(locationRequest);
        builder.setAlwaysShow(true);


        PendingResult<LocationSettingsResult> result =
                LocationServices.SettingsApi.checkLocationSettings(googleApiClient, builder.build());
        result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
            @Override
            public void onResult(LocationSettingsResult result) {
                final Status status = result.getStatus();
                if (status.getStatusCode() == LocationSettingsStatusCodes.RESOLUTION_REQUIRED) {
                    try {
                        startIntentSenderForResult(status.getResolution().getIntentSender(), REQUEST_LOCATION, null, 0, 0, 0, null);
                    } catch (IntentSender.SendIntentException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        if (ContextCompat.checkSelfPermission(mContext, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            if (mMap != null) {
                mMap.setMyLocationEnabled(true);
            }
        } else {
            requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == LOCATION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                checkLocationandAddToMap(location);
            } else {
                showLocationErrorDialog("Location permission not granted !");
                sendErrorToServer(empoyeeId, "Location permission not granted !", "Privilage id 38", "", "", "");
            }
        }
    }

    private void checkLocationandAddToMap(Location location) {
        mMap.clear();
        if (location != null) {
            //MarkerOptions are used to create a new Marker.You can specify location, title etc with MarkerOptions
            MarkerOptions markerOptions = new MarkerOptions().position(new LatLng(location.getLatitude(), location.getLongitude())).title(location.getLatitude() + "," + location.getLongitude());
            //Adding the created the marker on the map
            mMap.addMarker(markerOptions);
            //Move the camera to the user's location and zoom in!
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()), 14.0f));

        }
    }


    @Override
    public void onResume() {
        super.onResume();
        locationAddress = "";
        Log.e("MarkAttendance", "onResume");
        googleApiClient.connect();
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.e("MarkAttendance", "onPause");
        if (googleApiClient.isConnected()) {
            LocationServices.FusedLocationApi.removeLocationUpdates(googleApiClient, this);
            googleApiClient.disconnect();
        }
    }


    @Override
    public void onStop() {
        super.onStop();
        LocationService.removeCallbacks(null);

        mContext.stopService(new Intent(mContext, LocationService.class));

    }


    //Callback invoked once the GoogleApiClient is connected successfully
    @Override
    public void onConnected(Bundle bundle) {


        if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }


        LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, mLocationRequest, this);
        location = LocationServices.FusedLocationApi.getLastLocation(googleApiClient);

        if (location == null) {

            //  LogMaintainance.WriteLog("Location :"+location.getLatitude()+", "+location.getLongitude());

        } else {
            if (isMockLocationON(location)) {
                locationAddress = "mocklocation";
                tvAddress.setText(R.string.mocklocation);
                showMockAlert();
            } else {
                checkLocationandAddToMap(location);
            }

        }
    }


    @Override
    public void onConnectionSuspended(int i) {
        location = null;
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        /*
         * Google Play services can resolve some errors it detects.
         * If the error has a resolution, try sending an Intent to
         * start a Google Play services activity that can resolve
         * error.
         */
        if (connectionResult.hasResolution()) {
            try {
                // Start an Activity that tries to resolve the error
                connectionResult.startResolutionForResult((Activity) mContext, CONNECTION_FAILURE_RESOLUTION_REQUEST);
                /*
                 * Thrown if Google Play services canceled the original
                 * PendingIntent
                 */
            } catch (IntentSender.SendIntentException e) {
                // Log the error
                e.printStackTrace();
            }
        } else {
            /*
             * If no resolution is available, display a dialog to the
             * user with the error.
             */
            Log.i("Log", "Location services connection failed with code " + connectionResult.getErrorCode());
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_LOCATION) {
            onMapReady(mMap);
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }


    @Override
    public void onLocationChanged(Location location) {

        checkLocationandAddToMap(location);
        if (location != null) {

            if (isMockLocationON(location)) {
                locationAddress = "mocklocation";
                tvAddress.setText(R.string.mocklocation);
                showMockAlert();
            } else {
                LogMaintainance.WriteLog("NewTrackServiceActivity-> Location Changed " + location.getLatitude());
                //   addressDetails = new AddressDetails(mContext, location.getLatitude(), location.getLongitude());
                String locationAddress = Utilities.getAddressFromLateLong(mContext, location.getLatitude(), location.getLongitude());
                if (locationAddress.equals("")) {
                    locationAddress = "Latitude: " + location.getLatitude() + "\n" + location.getLongitude();
                }
                tvAddress.setText(locationAddress);
            }

        }


    }

    public boolean isMockLocationON(Location location) {
        boolean isMockLocation;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2 && location != null && location.isFromMockProvider()) {
            isMockLocation = true;
        } else {
            isMockLocation = !Settings.Secure.getString(getActivity().getContentResolver(), Settings.Secure.ALLOW_MOCK_LOCATION).equals("0");
        }
        return isMockLocation;
    }

    public void showMockAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setTitle("Mock Location is ON");
        builder.setMessage("Please disable the mock location for Punch In/Punch Out");
        builder.setCancelable(false);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();
    }


    @Override
    public void onClick(View v) {

        if (ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            switch (v.getId()) {
                case R.id.btn_punchIn:
                    if (location != null) {
                        if ((Utilities.isNetworkAvailable(mContext))) {

                            if (locationAddress.equals("mocklocation")) {
                                showMockAlert();
                            } else {
                                String locationAddress = Utilities.getAddressFromLateLong(getActivity(), location.getLatitude(), location.getLongitude());
                                if (locationAddress.equals("")) {
                                    locationAddress = "Latitude: " + location.getLatitude() + "\n" + location.getLongitude();
                                }
                                tvAddress.setText(locationAddress);
                                markAttendanceInOut(edt_messagefeedback.getText().toString(), String.valueOf(location.getLatitude()), String.valueOf(location.getLongitude()), locationAddress, "I");
                            }
                        } else {
                            Utilities.showDialog(coordinatorLayout, ErrorConstants.NO_NETWORK);
                        }
                    } else {
                        if (!isGPSTurnedOn()) {
                            moveToLocationSetting();
                        }

                    }
                    break;

                case R.id.btn_punchOut:
                    if (location != null) {
                        if ((Utilities.isNetworkAvailable(mContext))) {
                            if (locationAddress.equals("mocklocation")) {
                                showMockAlert();
                            } else {
                                String locationAddress = Utilities.getAddressFromLateLong(getActivity(), location.getLatitude(), location.getLongitude());
                                if (locationAddress.equals("")) {
                                    locationAddress = "Latitude: " + location.getLatitude() + "\n" + "Longitude:" + location.getLongitude();
                                }
                                tvAddress.setText(locationAddress);
                                markAttendanceInOut(edt_messagefeedback.getText().toString(), String.valueOf(location.getLatitude()), String.valueOf(location.getLongitude()), locationAddress, "O");
                            }
                        } else {
                            Utilities.showDialog(coordinatorLayout, ErrorConstants.NO_NETWORK);
                        }
                    } else {
                        if (!isGPSTurnedOn()) {
                            moveToLocationSetting();
                        }
                    }
                    break;
                default:

                    break;
            }
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 101);
        }


    }


    public void markAttendanceInOut(String comment, String lat, String lon, String location_address, String type) {
        try {
//            string userName, string empoyeeId, string securityToken, string attendanceRemark, string latitude, string longitude,string punchType
//            arlData = new ArrayList<HashMap<String,String>>();
            final ProgressDialog pDialog;
            pDialog = new ProgressDialog(mContext);
            pDialog.setMessage("Please wait...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();

            String url = Constants.IP_ADDRESS + "/SavvyMobileService.svc/SaveAttendanceMarkInOut";
            final JSONObject pm = new JSONObject();
            JSONObject params_final = new JSONObject();

            params_final.put("userName", username);
            params_final.put("empoyeeId", empoyeeId);
            params_final.put("securityToken", token);
            params_final.put("attendanceRemark", comment);
            params_final.put("latitude", lat);
            params_final.put("longitude", lon);
            params_final.put("punchType", type);
            params_final.put("location", location_address);
            Log.e(TAG, "markAttendanceInOut: " + params_final.toString());

            if (Utilities.isNetworkAvailable(mContext)) {
                RequestQueue requestQueue = Volley.newRequestQueue(mContext);
                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, params_final,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                Log.e("Value", " Length = " + (String.valueOf(response)).length() + " Value = " + response.toString());
                                pDialog.dismiss();

                                try {
                                    JSONObject jsonobj = response.getJSONObject("SaveAttendanceMarkInOutResult");
                                    String statusId = jsonobj.getString("statusId");
                                    String statusDescription = jsonobj.getString("statusDescription");
                                    String errorMessage = jsonobj.getString("errorMessage");

                                    if (statusId.equals("1")) {
                                        Utilities.showDialog(coordinatorLayout, statusDescription);
                                        edt_messagefeedback.setText("");
                                    } else if (statusId.equals("2")) {
                                        Utilities.showDialog(coordinatorLayout, statusDescription);
                                    }
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                    sendErrorToServer(empoyeeId, "SaveAttendanceMarkInOut", "Privilage id 38", ex.getMessage(), "", "");
                                }

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pDialog.dismiss();
                        sendErrorToServer(empoyeeId, "SaveAttendanceMarkInOut", "Privilage id 38", error.getMessage(), "", "");
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("securityToken", shared.getString("EMPLOYEE_ID_FINAL", ""));
                        return params;
                    }


                    @Override
                    public String getBodyContentType() {
                        return "application/json";
                    }
                };

                int socketTimeout = 3000000;
                RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                jsonObjectRequest.setRetryPolicy(policy);
                requestQueue.add(jsonObjectRequest);
            } else {
                Utilities.showDialog(coordinatorLayout, ErrorConstants.NO_NETWORK);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
