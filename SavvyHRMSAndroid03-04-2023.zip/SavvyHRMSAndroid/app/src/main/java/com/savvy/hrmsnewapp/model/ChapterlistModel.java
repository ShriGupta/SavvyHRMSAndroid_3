package com.savvy.hrmsnewapp.model;

/**
 * Created by Hari Om on 8/15/2016.
 */
public class ChapterlistModel {

    public String getChapter_id() {
        return chapter_id;
    }

    public void setChapter_id(String chapter_id) {
        this.chapter_id = chapter_id;
    }

    public String getChapter_name() {
        return chapter_name;
    }

    public void setChapter_name(String chapter_name) {
        this.chapter_name = chapter_name;
    }

    public String chapter_id;
    public String chapter_name;
}
