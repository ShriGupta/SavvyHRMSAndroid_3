package com.savvy.hrmsnewapp.model;

/**
 * Created by AM00347646 on 09-08-2016.
 */
public class NoticesDataModel {

    public String getNotices_id() {
        return notices_id;
    }

    public void setNotices_id(String notices_id) {
        this.notices_id = notices_id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getRemark_1() {
        return remark_1;
    }

    public void setRemark_1(String remark_1) {
        this.remark_1 = remark_1;
    }

    public String getRemark_2() {
        return remark_2;
    }

    public void setRemark_2(String remark_2) {
        this.remark_2 = remark_2;
    }

    public String getRemark_3() {
        return remark_3;
    }

    public void setRemark_3(String remark_3) {
        this.remark_3 = remark_3;
    }

    public String getRemark_4() {
        return remark_4;
    }

    public void setRemark_4(String remark_4) {
        this.remark_4 = remark_4;
    }

    public String getCancled_ago() {
        return cancled_ago;
    }

    public void setCancled_ago(String cancled_ago) {
        this.cancled_ago = cancled_ago;
    }

    public String notices_id;
    public String date;
    public String day;
    public String title;
    public String remark_1;
    public String remark_2;
    public String remark_3;
    public String remark_4;
    public String cancled_ago;


}
