package com.savvy.hrmsnewapp.model;

/**
 * Created by Amulya on 7/24/2016.
 */
public class TimeTableRootModel {

    public TimeTableModel getJson_data() {
        return json_data;
    }

    public void setJson_data(TimeTableModel json_data) {
        this.json_data = json_data;
    }

    public TimeTableModel json_data;
}
