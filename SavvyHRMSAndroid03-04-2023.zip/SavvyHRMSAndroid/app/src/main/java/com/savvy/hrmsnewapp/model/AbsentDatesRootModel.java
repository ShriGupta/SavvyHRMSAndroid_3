package com.savvy.hrmsnewapp.model;

/**
 * Created by Hari Om on 7/28/2016.
 */
public class AbsentDatesRootModel {

    public AbsentDatesModel getJson_data() {
        return json_data;
    }

    public void setJson_data(AbsentDatesModel json_data) {
        this.json_data = json_data;
    }

    public AbsentDatesModel json_data;
}
