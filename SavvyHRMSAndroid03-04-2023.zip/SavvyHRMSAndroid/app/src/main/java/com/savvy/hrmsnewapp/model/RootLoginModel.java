package com.savvy.hrmsnewapp.model;

/**
 * Created by AM00347646 on 11-07-2016.
 */
public class RootLoginModel {

    public ProfileModel getJson_data() {
        return json_data;
    }

    public void setJson_data(ProfileModel json_data) {
        this.json_data = json_data;
    }

    public ProfileModel json_data;
}
