package com.savvy.hrmsnewapp.model;

/**
 * Created by hariom on 26/7/16.
 */
public class TimeTableInfoRootModel {

    public TimeTableInfoModel getJson_data() {
        return json_data;
    }

    public void setJson_data(TimeTableInfoModel json_data) {
        this.json_data = json_data;
    }

    public TimeTableInfoModel json_data;
}
