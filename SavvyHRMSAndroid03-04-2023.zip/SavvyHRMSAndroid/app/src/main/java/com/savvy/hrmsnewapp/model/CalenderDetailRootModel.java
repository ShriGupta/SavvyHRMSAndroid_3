package com.savvy.hrmsnewapp.model;

/**
 * Created by Hari Om on 8/9/2016.
 */
public class CalenderDetailRootModel {

    public CalenderDetailModel getJson_data() {
        return json_data;
    }

    public void setJson_data(CalenderDetailModel json_data) {
        this.json_data = json_data;
    }

    CalenderDetailModel  json_data;
}
