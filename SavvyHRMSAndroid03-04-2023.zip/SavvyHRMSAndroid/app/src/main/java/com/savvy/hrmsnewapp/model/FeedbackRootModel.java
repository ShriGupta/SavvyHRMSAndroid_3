package com.savvy.hrmsnewapp.model;

/**
 * Created by Hari Om on 8/14/2016.
 */
public class FeedbackRootModel {

    public FeedbackModel getJson_data() {
        return json_data;
    }

    public void setJson_data(FeedbackModel json_data) {
        this.json_data = json_data;
    }

    public FeedbackModel json_data;
}
