package com.savvy.hrmsnewapp.fragment;

import static android.app.Activity.RESULT_OK;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;


import com.savvy.hrmsnewapp.R;

import com.savvy.hrmsnewapp.activity.DashBoardActivity;
import com.savvy.hrmsnewapp.adapter.AddMultipleItemsAdapter;
import com.savvy.hrmsnewapp.adapter.CustomSpinnerAdapter;
import com.savvy.hrmsnewapp.calendar.CalanderHRMS;
import com.savvy.hrmsnewapp.classes.RecyclerTouchListener;
import com.savvy.hrmsnewapp.customwidgets.CustomTextView;
import com.savvy.hrmsnewapp.interfaces.ClickListener;
import com.savvy.hrmsnewapp.interfaces.FilePathListener;
import com.savvy.hrmsnewapp.model.FileNameModel;
import com.savvy.hrmsnewapp.retrofitModel.MenuModule;
import com.savvy.hrmsnewapp.utils.Constants;
import com.savvy.hrmsnewapp.utils.ErrorConstants;
import com.savvy.hrmsnewapp.utils.Utilities;
import com.savvy.hrmsnewapp.volleyMultipart.MultipartRequest;
import com.savvy.hrmsnewapp.volleyMultipart.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class INOUTRequestFragment extends BaseFragment {

    protected CoordinatorLayout coordinatorLayout;
    ProgressDialog progressDialog;
    public static final String MY_PREFS_NAME = "MyPrefsFile";
    String token = "", employeeId = "", username = "";
    SharedPreferences shared;
    String displayFileName = "", actualFileName = "", other_actualFileName = "";
    private final String twoHyphens = "--";
    private final String lineEnd = "\r\n";
    private final String boundary = "apiclient-" + System.currentTimeMillis();
    private final String mimeType = "multipart/form-data;boundary=" + boundary;
    private byte[] multipartBody;
    Button btn_InOutdate, btn_otheruploadFile, btn_spin_meeting_type, btn_spin_work_type, btn_spin_charges_type, btn_TEuploadFile, txt_TEnoFileChoose, btn_spin_cab, btn_cabuploadFile, btn_submit;
    Spinner btn_spin_select_supplier, spin_comp_status, spin_meeting_type, spin_charge_type, spin_cab_type, spin_dropdown_type, hotel_book_spinner, flight_book_spinner, train_book_spinner;
    RecyclerView add_multiple_file;
    EditText edt_InOut_activity, edt_InOut_location, edt_InOut_sublocation, edt_InOut_conveyance, edt_InOut_amount, edt_InOut_remarks, edt_InOut_other;
    CalanderHRMS calanderHRMS;
    CustomSpinnerAdapter customspinnerAdapter;
    TextView btn_od_to_time;
    public static FilePathListener ml;
    public static Context context;
    boolean click_handle = false;
//    ODRequestFragmentAsync odRequestFragmentAsync;

    CustomTextView txt_AddMore, halfDay_on, firstHalf_on, secondHalf_on, fullDay_off, halfDay_off, firstHalf_off, secondHalf_off;

    String str_hour = "", str_minute = "";
    int pos, pos1;
    Uri mImageCaptureUri;
    private String selectedImagePath = "";
    LinearLayout cab_upload_file_layout, cab_amount_layout;
    CustomTextView txt_compareDate;
    Handler handler;
    Runnable rRunnable;

    String FROM_DATE = "", TO_DATE = "";
    String COMPARE_DATE = "";
    ArrayList<HashMap<String, String>> arlData, arlRequestStatusData;
    String positionId = "", positionValue = "";

    String spinnerPosition = "";
    String odsubstatusPosition = "0";
    String odStatusPosition = "1";
    CustomTextView txtOD_ReasonTitle, txtOD_TypeTitle, txtOD_ToDateTitle, txtOD_FromDateTitle;
    String supplierid = "", worktype = "", meetingtype = "", chargestype = "", cabtype = "", cabtmt = "", cabtype_id = "";
    RadioButton ncr_radio, non_ncr_radio;
    String check_click = "";
    int Position;
    String hotelid = "", flightid = "", trainid = "", hotelbookby = "", flightbookby = "", trainbookby = "";
    ArrayList<FileNameModel> multiple_item_list = new ArrayList<>();
    LinearLayout ncr_view_layout, non_ncr_view_layout;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (multiple_item_list != null) {
            multiple_item_list.clear();
        }
//        coordinatorLayout = getActivity().findViewById(R.id.coordinatorLayout);
//        shared = getActivity().getSharedPreferences(MY_PREFS_NAME, Context.MODE_PRIVATE);
//        token = (shared.getString("Token", ""));
//        employeeId = (shared.getString("EmpoyeeId", ""));
//        username = (shared.getString("UserName", ""));
//        arlRequestStatusData = new ArrayList<HashMap<String, String>>();
//
//        GetOvertimeReason getOvertimeReason = new GetOvertimeReason();
//        getOvertimeReason.execute();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.in_out_request_fragment, container, false);
        context = getActivity();
        coordinatorLayout = getActivity().findViewById(R.id.coordinatorLayout);
//
        calanderHRMS = new CalanderHRMS(getActivity());
//
        btn_InOutdate = view.findViewById(R.id.btn_InOutdate);
        btn_spin_select_supplier = view.findViewById(R.id.btn_spin_select_supplier);
        spin_comp_status = view.findViewById(R.id.spin_comp_status);
        spin_meeting_type = view.findViewById(R.id.spin_meeting_type);
        spin_charge_type = view.findViewById(R.id.spin_charge_type);
        spin_cab_type = view.findViewById(R.id.spin_cab_type);
        spin_dropdown_type = view.findViewById(R.id.spin_dropdown_type);
        edt_InOut_activity = view.findViewById(R.id.edt_InOut_activity);
        edt_InOut_location = view.findViewById(R.id.edt_InOut_location);
        edt_InOut_sublocation = view.findViewById(R.id.edt_InOut_sublocation);
        btn_cabuploadFile = view.findViewById(R.id.btn_cabuploadFile);
        edt_InOut_amount = view.findViewById(R.id.edt_InOut_amount);
        btn_od_to_time = view.findViewById(R.id.btn_od_to_time);
        btn_submit = view.findViewById(R.id.btn_od_request_submit);
        edt_InOut_remarks = view.findViewById(R.id.edt_InOut_remarks);
        edt_InOut_other = view.findViewById(R.id.edt_InOut_other);
        non_ncr_radio = view.findViewById(R.id.non_ncr_radio);
        ncr_radio = view.findViewById(R.id.ncr_radio);
        txt_AddMore = view.findViewById(R.id.txt_AddMore);
        add_multiple_file = view.findViewById(R.id.add_multiple_file);
        non_ncr_view_layout = view.findViewById(R.id.non_ncr_view_layout);
        ncr_view_layout = view.findViewById(R.id.ncr_view_layout);
        hotel_book_spinner = view.findViewById(R.id.hotel_book_spinner);
        flight_book_spinner = view.findViewById(R.id.flight_book_spinner);
        train_book_spinner = view.findViewById(R.id.train_book_spinner);
        btn_otheruploadFile = view.findViewById(R.id.btn_otheruploadFile);
        cab_upload_file_layout = view.findViewById(R.id.cab_upload_file_layout);
        cab_amount_layout = view.findViewById(R.id.cab_amount_layout);
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            String currentDateandTime = sdf.format(new Date());
            btn_od_to_time.setText(currentDateandTime);
        } catch (Exception e) {
        }
//        btn_od_to_date = view.findViewById(R.id.btn_to_oddate);
//        btn_od_from_time = view.findViewById(R.id.btn_od_time_from);
//        btn_od_to_time = view.findViewById(R.id.btn_od_to_time);
//        //btn_submit = (Button)view.findViewById(R.id.btn_od_request_submit);
//        btnOdRequestSubmit = view.findViewById(R.id.btn_od_request_submit);
//        spin_reason_od = view.findViewById(R.id.spin_od_reason);
//        edt_od_reason = view.findViewById(R.id.edt_od_reason);
//
//        linear_compareDate = view.findViewById(R.id.linear_compareDate);
//        txt_compareDate = view.findViewById(R.id.txt_compareDate);
//        linear_compareDate.setVisibility(View.GONE);
//
//        txtOD_ReasonTitle = view.findViewById(R.id.txtOD_ReasonTitle);
//        txtOD_TypeTitle = view.findViewById(R.id.txtOD_TypeTitle);
//        txtOD_ToDateTitle = view.findViewById(R.id.txtOD_ToDateTitle);
//        txtOD_FromDateTitle = view.findViewById(R.id.txtOD_FromDateTitle);
//
//        String str1 = "<font color='#EE0000'>*</font>";
//
//        txtOD_ReasonTitle.setText(Html.fromHtml("Reason " + str1));
//        txtOD_TypeTitle.setText(Html.fromHtml("OD Type " + str1));
//        txtOD_ToDateTitle.setText(Html.fromHtml("To Date " + str1));
//        txtOD_FromDateTitle.setText(Html.fromHtml("From Date " + str1));
//
//        fullDay_on = view.findViewById(R.id.fullDay_on);
//        fullDay_off = view.findViewById(R.id.fullDay_off);
//        halfDay_on = view.findViewById(R.id.halfDay_on);
//        halfDay_off = view.findViewById(R.id.halfDay_off);
//        firstHalf_on = view.findViewById(R.id.first_half_on);
//        firstHalf_off = view.findViewById(R.id.first_half_off);
//        secondHalf_on = view.findViewById(R.id.second_half_on);
//        secondHalf_off = view.findViewById(R.id.second_half_off);
//
//        firstHalf_on.setEnabled(false);
//        secondHalf_on.setEnabled(false);
//        firstHalf_off.setEnabled(false);
//        secondHalf_off.setEnabled(false);
//
//        firstHalf_on.setTextColor(Color.parseColor("#DCDADE"));
//        secondHalf_on.setTextColor(Color.parseColor("#DCDADE"));
//        firstHalf_off.setTextColor(Color.parseColor("#DCDADE"));
//        secondHalf_off.setTextColor(Color.parseColor("#DCDADE"));
        FileNameModel fileNameModel = new FileNameModel();
        fileNameModel.setFile_name("");
        fileNameModel.setPosition(0);
        multiple_item_list.add(fileNameModel);
        addMultipleItem();
        txt_AddMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                click_handle = true;
                FileNameModel fileNameModel = new FileNameModel();
                fileNameModel.setFile_name("");
                fileNameModel.setPosition(0);
                multiple_item_list.add(fileNameModel);
                addMultipleItem();
            }
        });
        btn_InOutdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btn_InOutdate.setText("");
                calanderHRMS.datePickerWithOtherFormate(btn_InOutdate);
                getSupplierData(btn_InOutdate.getText().toString());
            }
        });
        btn_cabuploadFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    check_click = "";
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("*/*");
                    startActivityForResult(intent, 999);
                } catch (Exception e) {
                }
            }
        });
        btn_otheruploadFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    check_click = "other";
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("*/*");
                    startActivityForResult(intent, 999);
                } catch (Exception e) {
                }
            }
        });
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveAllDetails();
            }
        });
        shared = getActivity().getSharedPreferences(MY_PREFS_NAME, Context.MODE_PRIVATE);

        // getSupplierData("04/03/2023");
        getWorkType();
        getMeetingType();
        getChargeType();
        getCabType();
        getDropDownType();


//        fullDay_off.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                firstHalf_on.setEnabled(false);
//                secondHalf_on.setEnabled(false);
//                firstHalf_off.setEnabled(false);
//                secondHalf_off.setEnabled(false);
//
//                firstHalf_on.setTextColor(Color.parseColor("#DCDADE"));
//                secondHalf_on.setTextColor(Color.parseColor("#DCDADE"));
//                firstHalf_off.setTextColor(Color.parseColor("#DCDADE"));
//                secondHalf_off.setTextColor(Color.parseColor("#DCDADE"));
//
//                fullDay_on.setVisibility(View.VISIBLE);
//                fullDay_off.setVisibility(View.INVISIBLE);
//                halfDay_on.setVisibility(View.INVISIBLE);
//                halfDay_off.setVisibility(View.VISIBLE);
//                firstHalf_on.setVisibility(View.INVISIBLE);
//                firstHalf_off.setVisibility(View.VISIBLE);
//                secondHalf_on.setVisibility(View.INVISIBLE);
//                secondHalf_off.setVisibility(View.VISIBLE);
//
//                odStatusPosition = "" + "1";
//                odsubstatusPosition = "" + "0";
//                Log.e("Full Day", "" + odStatusPosition);
//
//            }
//        });
//
//        halfDay_off.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                firstHalf_on.setEnabled(true);
//                secondHalf_on.setEnabled(true);
//                firstHalf_off.setEnabled(true);
//                secondHalf_off.setEnabled(true);
//
//                firstHalf_on.setTextColor(Color.parseColor("#404040"));
//                secondHalf_on.setTextColor(Color.parseColor("#404040"));
//                firstHalf_off.setTextColor(Color.parseColor("#404040"));
//                secondHalf_off.setTextColor(Color.parseColor("#404040"));
//
//                fullDay_on.setVisibility(View.INVISIBLE);
//                fullDay_off.setVisibility(View.VISIBLE);
//                halfDay_on.setVisibility(View.VISIBLE);
//                halfDay_off.setVisibility(View.INVISIBLE);
//                firstHalf_on.setVisibility(View.VISIBLE);
//                firstHalf_off.setVisibility(View.INVISIBLE);
//
//                odStatusPosition = "" + "2";
//                odsubstatusPosition = "" + "1";
//                Log.e("Half Day", "" + odStatusPosition);
//                Log.e("First half", "" + odsubstatusPosition);
//            }
//        });
//
//        firstHalf_off.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                firstHalf_on.setEnabled(true);
//                secondHalf_on.setEnabled(true);
//                firstHalf_off.setEnabled(true);
//                secondHalf_off.setEnabled(true);
//
//                firstHalf_on.setVisibility(View.VISIBLE);
//                firstHalf_off.setVisibility(View.INVISIBLE);
//                secondHalf_on.setVisibility(View.INVISIBLE);
//                secondHalf_off.setVisibility(View.VISIBLE);
//
//                odsubstatusPosition = "" + "1";
//                Log.e("First Half", "" + odsubstatusPosition);
//
//            }
//        });
//
//        secondHalf_off.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                firstHalf_on.setEnabled(true);
//                secondHalf_on.setEnabled(true);
//                firstHalf_off.setEnabled(true);
//                secondHalf_off.setEnabled(true);
//
//                firstHalf_on.setVisibility(View.INVISIBLE);
//                firstHalf_off.setVisibility(View.VISIBLE);
//                secondHalf_on.setVisibility(View.VISIBLE);
//                secondHalf_off.setVisibility(View.INVISIBLE);
//
//                odsubstatusPosition = "" + "2";
//                Log.e("Secon Half", "" + odsubstatusPosition);
//            }
//        });


//        String[] str_reason = {"Please Select","Client Meeting","On Site","Work From Home","Other"};
//
//        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getActivity(),R.layout.spinner_item,str_reason);
//        spin_reason_od.setAdapter(arrayAdapter);

//        spin_reason_od.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                try {
//                    if (position == 0) {
//                        positionValue = "";
//                        positionId = "";
//                    } else if (position > 0) {
//                        positionId = arlRequestStatusData.get(position - 1).get("KEY");
//                        positionValue = arlRequestStatusData.get(position - 1).get("VALUE");
//                    }
//                    Log.e("Spin Value", "Spin Id " + positionId + " Value " + positionValue);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//            }
//        });
//
//        btn_od_from_date.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                btn_od_from_date.setText("");
//                calanderHRMS.datePicker(btn_od_from_date);
//
//                handler = new Handler();
//                rRunnable = new Runnable() {
//                    @Override
//                    public void run() {
//                        try {
//                            FROM_DATE = btn_od_from_date.getText().toString().trim();
//                            TO_DATE = btn_od_to_date.getText().toString().trim();
//
//                            if (!FROM_DATE.equals("") && !TO_DATE.equals("")) {
//                                getCompareTodayDate(FROM_DATE, TO_DATE);
//                            } else {
//                                handler.postDelayed(rRunnable, 1000);
//                            }
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                            Log.e("GetFuture Method ", e.getMessage());
//                        }
//                    }
//                };
//                handler.postDelayed(rRunnable, 1000);
//            }
//        });
//        btn_od_to_date.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                btn_od_to_date.setText("");
//                calanderHRMS.datePicker(btn_od_to_date);
//
//                handler = new Handler();
//                rRunnable = new Runnable() {
//                    @Override
//                    public void run() {
//                        try {
//                            FROM_DATE = btn_od_from_date.getText().toString().trim();
//                            TO_DATE = btn_od_to_date.getText().toString().trim();
//
//                            if (!FROM_DATE.equals("") && !TO_DATE.equals("")) {
//                                getCompareTodayDate(FROM_DATE, TO_DATE);
//                            } else {
//                                handler.postDelayed(rRunnable, 1000);
//                            }
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                            Log.e("GetFuture Method ", e.getMessage());
//                        }
//                    }
//                };
//                handler.postDelayed(rRunnable, 1000);
//            }
//        });
//
//        btn_od_from_time.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                calanderHRMS.timePicker(btn_od_from_time);
//            }
//        });
//
//        btn_od_to_time.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                calanderHRMS.timePicker(btn_od_to_time);
//            }
//        });
//
//        btnOdRequestSubmit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                String fromDate = "", toDate = "", fromTime = "", toTime = "", edtreason = "", odtype = "", od_status = "", odsubstatus = "";
//
//                fromDate = btn_od_from_date.getText().toString().trim().replace("/", "-");
//                toDate = btn_od_to_date.getText().toString().trim().replace("/", "-");
//                fromTime = btn_od_from_time.getText().toString().trim().replace(":", "-").replace(" ", "_");
//                toTime = btn_od_to_time.getText().toString().trim().replace(":", "-").replace(" ", "_");
//                edtreason = edt_od_reason.getText().toString().trim();
//                odtype = positionId;
//                od_status = odStatusPosition;
//                odsubstatus = odsubstatusPosition;
//
//                Log.v("Radio Button", "OD Status " + od_status + "   OD Sub Status " + odsubstatus);
//                System.out.print("OD Status " + od_status + "   OD Sub Status " + odsubstatus);
//
//                if (fromDate.equals("")) {
//                    Log.v("From Date", "Error1");
//                    Utilities.showDialog(coordinatorLayout, "Please Enter From Date.");
//                } else if (toDate.equals("")) {
//                    Log.v("To Date", "Error2");
//                    Utilities.showDialog(coordinatorLayout, "Please Enter To Date.");
//
//                } else if (odtype.equals("")) {
//                    Log.v("OD Type", "Error3");
//                    Utilities.showDialog(coordinatorLayout, "Please Enter OD Type.");
//
//                } else if (edtreason.equals("")) {
//                    Log.v("Reaon", "Error4");
//                    Utilities.showDialog(coordinatorLayout, "Please Enter Reason.");
//
//                } else {
//                    if (Utilities.isNetworkAvailable(getActivity())) {
////                        odRequestFragmentAsync = new ODRequestFragment.ODRequestFragmentAsync();
////                        odRequestFragmentAsync.execute(fromDate, toDate, fromTime, toTime, odtype, od_status, odsubstatus, edtreason);
////
////                        btn_od_from_date.setHint("From Date");
////                        btn_od_to_date.setHint("To Date");
////                        btn_od_from_time.setHint("From Time");
////                        btn_od_to_time.setHint("To Time");
////                        edt_od_reason.setHint("Reason");
//                        Send_OD_Request(employeeId, "0", fromDate, toDate, od_status, odsubstatus, fromTime, toTime, odtype, edtreason);
//
//                    } else {
//
//                        Utilities.showDialog(coordinatorLayout, ErrorConstants.NO_NETWORK);
//                    }
//                }
//
//
//            }
//        });

        return view;
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // alertD.dismiss();
        if (requestCode == 999 && resultCode == RESULT_OK && data != null) {
            try {

                Uri uri = data.getData();
                String uriString = uri.toString();
                File myFile = new File(uriString);
                getImageFromDevide(uri, myFile);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (requestCode == 1000 && resultCode == RESULT_OK) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            Uri uri = getImageUri(getActivity(), photo);
            File finalFile = new File(getRealPathFromURI(uri));

            getImageFromDevide(uri, finalFile);
        }
    }


    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    public String getRealPathFromURI(Uri uri) {
        String path = "";
        if (getActivity().getContentResolver() != null) {
            Cursor cursor = getActivity().getContentResolver().query(uri, null, null, null, null);
            if (cursor != null) {
                cursor.moveToFirst();
                int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
                path = cursor.getString(idx);
                cursor.close();
            }
        }
        return path;
    }

    public void getImageFromDevide(Uri uri, File finalFile) {
        byte[] byteArray = new byte[0];
        String uriString = uri.toString();
        if (uriString.startsWith("content://")) {
            Cursor cursor = null;
            try {
                cursor = getActivity().getContentResolver().query(uri, null, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    displayFileName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            } finally {
                cursor.close();
            }
        } else if (uriString.startsWith("file://")) {
            displayFileName = finalFile.getName();
        }
        try {
            File file = new File(uri.getPath());
            byteArray = new byte[(int) file.length()];

        } catch (Exception e) {
            e.printStackTrace();

        }
        //  txt_imageUpload.setText(displayFileName);
        imageProcessRequest(byteArray, displayFileName);
    }

    private void odRequest(String fromDate, String toDate, String fromTime, String toTime, String edtreason,
                           String odstatus, String odsubstatus, String odtype) {

        System.out.print("\n\nInside OD request Click  : OD type = " + odtype + " OD Status = " + odstatus + " OD Sub Status =  " + odsubstatus
                + "\n\nFrom Time = " + fromTime + " To time = " + toTime + "\n\nFrom Date = " + fromDate + " To date = " + toDate + " Reason = " + edtreason);

        try {
            if (Utilities.isNetworkAvailable(getActivity())) {

//                odRequestFragmentAsync = new ODRequestFragment.ODRequestFragmentAsync();
//                odRequestFragmentAsync.from_date = fromDate;
//                odRequestFragmentAsync.to_date = toDate;
//                odRequestFragmentAsync.from_time = fromTime;
//                odRequestFragmentAsync.to_time = toTime;
//                odRequestFragmentAsync.edtreason = edtreason;
//                odRequestFragmentAsync.odstatus = ""+odstatus;
//                odRequestFragmentAsync.odsubstatus = odsubstatus;
//                odRequestFragmentAsync.odtype = odtype;
//
//                odRequestFragmentAsync.execute();
            } else {
                Utilities.showDialog(coordinatorLayout, ErrorConstants.NO_NETWORK);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        coordinatorLayout = getActivity().findViewById(R.id.coordinatorLayout);
    }


//    public void Send_OD_Request(String emp_id, String req_id, String fromDate, String toDate, String od_type,
//                                String od_sub_type, String fromTime, String toTime, String odType, String reason) {
//        try {
//            if (toTime.equals("")) {
//                toTime = "-";
//            }
//            if (fromTime.equals("")) {
//                fromTime = "-";
//            }
//            JSONObject param = new JSONObject();
//
//            param.put("EMPLOYEE_ID", emp_id);
//            param.put("REQUEST_ID", req_id);
//            param.put("FROM_DATE", fromDate);
//            param.put("TO_DATE", toDate);
//            param.put("OD_REQUEST_TYPE", od_type);
//            param.put("OD_REQUEST_SUB_TYPE", od_sub_type);
//            param.put("FROM_TIME", fromTime);
//            param.put("TO_TIME", toTime);
//            param.put("OD_TYPE", odType);
//            param.put("REASON", reason);
//            Log.e("RequestJson", param.toString());
//
//            String url = Constants.IP_ADDRESS + "/SavvyMobileService.svc/SendOdRequestPost";
//            Log.e("Send url", url);
//
//            RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
//            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, param,
//                    new Response.Listener<JSONObject>() {
//                        @Override
//                        public void onResponse(JSONObject response) {
//                            try {
//                                String result = response.getString("SendODRequestPostResult");
//                                int res = Integer.parseInt(result);
//                                if (res > 0) {
//                                    btn_od_from_date.setText("");
//                                    btn_od_to_date.setText("");
//                                    btn_od_from_time.setText("");
//                                    btn_od_to_time.setText("");
//                                    spin_reason_od.setSelection(0);
//                                    edt_od_reason.setText("");
//                                    Utilities.showDialog(coordinatorLayout, "On Duty request Send successfully.");
//                                } else if (res == -1) {
//                                    Utilities.showDialog(coordinatorLayout, "On Duty request on the same date and same type already exists.");
//                                } else if (res == -2) {
//                                    Utilities.showDialog(coordinatorLayout, "On Duty request for previous payroll cycle not allowed.");
//                                } else if (res == -3) {
//                                    Utilities.showDialog(coordinatorLayout, "OD/AR/Leave on Same Date Already Requested.");
//                                } else if (res == 0) {
//                                    Utilities.showDialog(coordinatorLayout, "Error during sending On Duty Request.");
//                                }
//                            } catch (Exception ex) {
//                                ex.printStackTrace();
//                                Utilities.showDialog(coordinatorLayout, ex.getMessage());
//                            }
//                        }
//                    }, new Response.ErrorListener() {
//                @Override
//                public void onErrorResponse(VolleyError error) {
//                    Utilities.showDialog(coordinatorLayout, Utilities.handleVolleyError(error));
//                }
//            }) {
//                @Override
//                public Map<String, String> getHeaders() throws AuthFailureError {
//                    Map<String, String> params = new HashMap<String, String>();
//                    params.put("securityToken", shared.getString("EMPLOYEE_ID_FINAL", ""));
//                    return params;
//                }
//
//
//                @Override
//                public String getBodyContentType() {
//                    return "application/json";
//                }
//            };
//
//            int socketTime = 30000;
//            RetryPolicy retryPolicy = new DefaultRetryPolicy(socketTime, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
//            jsonObjectRequest.setRetryPolicy(retryPolicy);
//            requestQueue.add(jsonObjectRequest);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    private class ODRequestFragmentAsync extends AsyncTask<String, String, String> {
//        private ProgressDialog pDialog;
//
////        String from_date,to_date,from_time,to_time;
////        String edtreason,odtype,odstatus="",odsubstatus;
//
//
//        @Override
//        protected void onPreExecute() {
//            // Things to be done before execution of long running operation. For
//            // example showing ProgessDialog
//            pDialog = new ProgressDialog(getActivity());
//            pDialog.setMessage("Please wait...");
//            pDialog.setIndeterminate(false);
//            pDialog.setCancelable(true);
//            pDialog.show();
//
//        }
//
//        @Override
//        protected String doInBackground(String... params) {
//            String from_date, to_date, from_time, to_time;
//            String edtreason, odtype, od_status, odsubstatus;
//
//            from_date = params[0];
//            to_date = params[1];
//            from_time = params[2];
//            to_time = params[3];
//            odtype = params[4];
//            od_status = params[5];
//            odsubstatus = params[6];
//            edtreason = params[7];
//            //publishProgress("Sleeping..."); // Calls onProgressUpdate()
//            System.out.print("\n\nDo in background From Time = " + from_date + " To Time=  " + to_date + " From Time= " + from_time + " To Time  " + to_time +
//                    "\n\nReason = " + edtreason + " OD type =  " + odtype + " \n\nOd Status  " + od_status + " Od Sub Status  " + odsubstatus);
//
//            if (from_time.equals("")) {
//                from_time = "-";
//            }
//            if (to_time.equals("")) {
//                to_time = "-";
//            }
//            try {
//
//                //String LOGIN_URL = "http://savvyshippingsoftware.com/SavvyMobile/SavvyMobileService.svc//GetCurrentDateTime";
//                String OdRequestURL = Constants.IP_ADDRESS + "/SavvyMobileService.svc/SendODRequest/" + employeeId + "/" + "0" + "/" + from_date + "/" + to_date + "/" + od_status + "/" + odsubstatus + "/" + from_time + "/" + to_time + "/" + odtype + "/" + edtreason;
//
//                //String OdRequestURL = "http://savvyshippingsoftware.com/SavvyMobileNew/SavvyMobileService.svc/SendODRequest/" + empoyeeId + "/" + "0" + "/" + "10-05-2017" + "/" + "11-05-2017" + "/" + "1" + "/" + "0" + "/" + "08-08_AM" + "/" + "09-08_AM" + "/" + "1" + "/" + "ujhgha";
//
//                System.out.println("OdRequestURL====" + OdRequestURL);
//                JSONParser jParser = new JSONParser(getActivity()); // get JSON data from URL JSONArray json = jParser.getJSONFromUrl(url);
//                String json = jParser.makeHttpRequest(
//                        OdRequestURL, "GET");
//
//                if (json != null) {
//                    Log.d("JSON result", json.toString());
//
//                    return json;
//                }
//                //jsonlist.add(map);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//
//
//            return null;
//        }
//
//        @Override
//        protected void onPostExecute(String result) {
//
//
//            if (pDialog != null && pDialog.isShowing()) {
//                pDialog.dismiss();
//
//                result = result.replaceAll("^\"+|\"+$", " ").trim();
//                try {
//
//                    int res = Integer.valueOf(result);
//                    if (res > 0) {
//                        Utilities.showDialog(coordinatorLayout, "On Duty request Send successfully.");
//                    } else if (res == -1) {
//                        Utilities.showDialog(coordinatorLayout, "On Duty request on the same date and same type already exists.");
//                    } else if (res == -2) {
//                        Utilities.showDialog(coordinatorLayout, "On Duty request for previous payroll cycle not allowed.");
//                    } else if (res == -3) {
//                        Utilities.showDialog(coordinatorLayout, "OD/AR/Leave on Same Date Already Requested.");
//                    } else if (res == 0) {
//                        Utilities.showDialog(coordinatorLayout, "Error during sending On Duty Request.");
//                    }
//                } catch (Exception ex) {
//                    ex.printStackTrace();
//                }
//
////               if(result.equals("0")) {
////                        Utilities.showDialog(coordinatorLayout, "On Duty request send successfully.");
////                    }else if(result.equals("-1")){
////                        Utilities.showDialog(coordinatorLayout,"On Duty request on the same date and same type already exists.");
////                    }else if(result.equals("-2")) {
////                        Utilities.showDialog(coordinatorLayout,"On Duty request for previous payroll cycle not allowed.");
////                    }else if(result.equals(" -3 ")) {
////                        System.out.print("This is the output "+result);
////                       Utilities.showDialog(coordinatorLayout,"Request already applied in the same date.");
////                    }else if(result==" -3 "){
////                        System.out.print("This is the Another output "+result);
////                        Utilities.showDialog(coordinatorLayout,"Error in -3");
////                    }
////
////
//                btn_od_from_date.setText("");
//                btn_od_to_date.setText("");
//                btn_od_from_time.setText("");
//                btn_od_to_time.setText("");
//                edt_od_reason.setText("");
//            }
//        }
//
//        @Override
//        protected void onProgressUpdate(String... text) {
//            // finalResult.setText(text[0]);
//            // Things to be done while execution of long running operation is in
//            // progress. For example updating ProgessDialog
//        }
//
//
//    }

    public void getSupplierData(String From_date) {
        try {
            if (Utilities.isNetworkAvailable(getActivity())) {
                String From_Date = From_date;


                String url = Constants.IP_ADDRESS + "/SavvyMobileService.svc/GetSupplierData";
                final JSONObject pm = new JSONObject();
                JSONObject params_final = new JSONObject();
                params_final.put("datetime", From_Date);
                params_final.put("employeeId", shared.getString("EMPLOYEE_ID_FINAL", ""));


//            pm.put("objSendConveyanceRequestInfo", params_final);

                RequestQueue requestQueue = Volley.newRequestQueue(getContext());

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, params_final,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                int len = (String.valueOf(response)).length();

                                System.out.print("Array " + " Length = " + len + " Value = " + response.toString());
                                Log.e("getSupplierData", "<>><>" + response.toString());

                                try {
//                                    JSONArray jsonArray = new JSONArray(response);
                                    JSONArray jsonArray = response.getJSONArray("GetSupplierDataResult");
                                    ArrayList<String> spinnerArray = new ArrayList<>();
                                    ArrayList<String> spinnerItemIDArray = new ArrayList<>();
                                    if (jsonArray.length() > 0) {
                                        for (int i = 0; i < jsonArray.length(); i++) {
                                            JSONObject explrObject = jsonArray.getJSONObject(i);
                                            String sm_supplier_name = explrObject.getString("SM_SUPPLIER_NAME");
                                            String SM_SUPPLIER_ID = explrObject.getString("SM_SUPPLIER_ID");
                                            spinnerArray.add(sm_supplier_name);
                                            spinnerItemIDArray.add(SM_SUPPLIER_ID);
                                        }
                                    }
                                    ArrayAdapter spinnerArrayAdapter = new ArrayAdapter(getActivity(),
                                            android.R.layout.simple_spinner_dropdown_item,
                                            spinnerArray);
                                    btn_spin_select_supplier.setAdapter(spinnerArrayAdapter);
                                    btn_spin_select_supplier.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                                            // your code here
                                            supplierid = spinnerItemIDArray.get(position).toString();
                                            getShowDetailsBySupplier(spinnerItemIDArray.get(position).toString(), From_Date);

                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parentView) {
                                            // your code here
                                        }

                                    });
//                                    boolean resultDate = response.getBoolean("Compare_DateResult");
//                                    if (!resultDate) {
//                                        txt_compareDate.setText("From Date should be less than or equal To Date!");
//                                        linear_compareDate.setVisibility(View.VISIBLE);
//                                    } else {
//                                        linear_compareDate.setVisibility(View.GONE);
//                                    }
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                    Log.e("Error In", "" + ex.getMessage());
                                }

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Log.d("Error", "" + error.getMessage());
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("securityToken", shared.getString("EMPLOYEE_ID_FINAL", ""));
                        return params;
                    }


                    @Override
                    public String getBodyContentType() {
                        return "application/json";
                    }
                };

                int socketTimeout = 3000000;
                RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                jsonObjectRequest.setRetryPolicy(policy);
                requestQueue.add(jsonObjectRequest);
            } else {
                Utilities.showDialog(coordinatorLayout, ErrorConstants.NO_NETWORK);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //activity ------------------------------------------------------------
    //SharedPreferences.Editor editor = shared.edit();

    public void getShowDetailsBySupplier(String id, String To_date) {
        try {
            if (Utilities.isNetworkAvailable(getActivity())) {
                // String From_Date = From_date;
                String To_Date = To_date;

                Log.e("TAG", "activity" + To_Date);
                String url = Constants.IP_ADDRESS + "/SavvyMobileService.svc/ShowDetailsBySupplier";
                final JSONObject pm = new JSONObject();
                JSONObject params_final = new JSONObject();
                params_final.put("employeeId", shared.getString("EMPLOYEE_ID_FINAL", ""));
                params_final.put("supplierid", id);
                params_final.put("date", To_Date);
                supplierid = id;
                getCheckInCheckOutForButton();


//            pm.put("objSendConveyanceRequestInfo", params_final);

                RequestQueue requestQueue = Volley.newRequestQueue(getContext());

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, params_final,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                int len = (String.valueOf(response)).length();
                                Log.e("TAG", "activityResponse" + response.toString());

                                System.out.print("Array " + " Length = " + len + " Value = " + response.toString());
                                // Log.e("Value", " Length = " + len + " Value = " + response.toString());

                                try {
//                                    JSONArray jsonArray = new JSONArray(response);
                                    JSONArray jsonArray = response.getJSONArray("ShowDetailsBySupplierResult");
                                    Log.e("TAG", "activityResponseArray" + jsonArray.length());
                                    if (jsonArray.length() > 0) {
                                        for (int i = 0; i <= jsonArray.length()-1; i++) {
                                            JSONObject explrObject = jsonArray.getJSONObject(i);
                                            Log.e("TAG", "activityResponseArrayacti" + explrObject.getString("AM_ACTIVITY_NAME"));

                                            edt_InOut_activity.setText(explrObject.getString("AM_ACTIVITY_NAME"));
                                            edt_InOut_location.setText(explrObject.getString("SLD_LOCATION"));
                                            edt_InOut_sublocation.setText(explrObject.getString("TLM_LOCATION"));
                                            //edt_InOut_conveyance.setText(explrObject.getString("SLD_CONVEYANCE"));



                                            if (explrObject.getString("SLD_NCR_TYPE").equals("2")) {
                                                non_ncr_radio.setChecked(true);
                                                ncr_radio.setChecked(false);
                                                non_ncr_view_layout.setVisibility(View.VISIBLE);
                                                ncr_view_layout.setVisibility(View.GONE);

                                                //editor.putString("ncr", "2");
                                                //editor.apply();
                                            } else if (explrObject.getString("SLD_NCR_TYPE").equals("1")) {
                                                ncr_radio.setChecked(true);
                                                non_ncr_radio.setChecked(false);
                                                non_ncr_view_layout.setVisibility(View.GONE);
                                                ncr_view_layout.setVisibility(View.VISIBLE);
                                                //editor.putString("ncr", "1");
                                                //editor.apply();
                                            }


                                        }

                                    }
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                    Log.e("Error In", "" + ex.getMessage());
                                }

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Log.d("Error", "" + error.getMessage());
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("securityToken", shared.getString("EMPLOYEE_ID_FINAL", ""));
                        return params;
                    }


                    @Override
                    public String getBodyContentType() {
                        return "application/json";
                    }
                };

                int socketTimeout = 3000000;
                RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                jsonObjectRequest.setRetryPolicy(policy);
                requestQueue.add(jsonObjectRequest);
            } else {
                Utilities.showDialog(coordinatorLayout, ErrorConstants.NO_NETWORK);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void getWorkType() {
        try {
            if (Utilities.isNetworkAvailable(getActivity())) {

                String url = Constants.IP_ADDRESS + "/SavvyMobileService.svc/GetWorkType";
                final JSONObject pm = new JSONObject();
                JSONObject params_final = new JSONObject();

                params_final.put("employeeId", shared.getString("EMPLOYEE_ID_FINAL", ""));


//            pm.put("objSendConveyanceRequestInfo", params_final);

                RequestQueue requestQueue = Volley.newRequestQueue(getContext());

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, params_final,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                int len = (String.valueOf(response)).length();

                                System.out.print("Array " + " Length = " + len + " Value = " + response.toString());
                                Log.e("Value2", " Length = " + len + " Value = " + response.toString());

                                try {
//                                    JSONArray jsonArray = new JSONArray(response);
                                    JSONArray jsonArray = response.getJSONArray("GetWorkTypeResult");
                                    ArrayList<String> spinnerArray = new ArrayList<>();
                                    ArrayList<String> spinneridArray = new ArrayList<>();
                                    if (jsonArray.length() > 0) {
                                        for (int i = 0; i < jsonArray.length(); i++) {
                                            JSONObject explrObject = jsonArray.getJSONObject(i);
                                            String sm_supplier_name = explrObject.getString("Type");
                                            String SM_SUPPLIER_ID = explrObject.getString("Value");
                                            spinnerArray.add(sm_supplier_name);
                                            spinneridArray.add(SM_SUPPLIER_ID);
                                        }
                                    }
                                    ArrayAdapter spinnerArrayAdapter = new ArrayAdapter(getActivity(),
                                            android.R.layout.simple_spinner_dropdown_item,
                                            spinnerArray);
                                    spin_comp_status.setAdapter(spinnerArrayAdapter);
                                    spin_comp_status.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                                            // your code here
                                            worktype = spinneridArray.get(position).toString();

                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parentView) {
                                            // your code here
                                        }

                                    });
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                    Log.e("Error In", "" + ex.getMessage());
                                }

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Log.d("Error", "" + error.getMessage());
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("securityToken", shared.getString("EMPLOYEE_ID_FINAL", ""));
                        return params;
                    }


                    @Override
                    public String getBodyContentType() {
                        return "application/json";
                    }
                };

                int socketTimeout = 3000000;
                RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                jsonObjectRequest.setRetryPolicy(policy);
                requestQueue.add(jsonObjectRequest);
            } else {
                Utilities.showDialog(coordinatorLayout, ErrorConstants.NO_NETWORK);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getMeetingType() {
        try {
            if (Utilities.isNetworkAvailable(getActivity())) {

                String url = Constants.IP_ADDRESS + "/SavvyMobileService.svc/GetMeetingType";
                final JSONObject pm = new JSONObject();
                JSONObject params_final = new JSONObject();

                params_final.put("employeeId", shared.getString("EMPLOYEE_ID_FINAL", ""));


//            pm.put("objSendConveyanceRequestInfo", params_final);

                RequestQueue requestQueue = Volley.newRequestQueue(getContext());

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, params_final,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                int len = (String.valueOf(response)).length();

                                System.out.print("Array " + " Length = " + len + " Value = " + response.toString());
                                Log.e("getMeetingType", " Length = " + len + " Value = " + response.toString());

                                try {
//                                    JSONArray jsonArray = new JSONArray(response);
                                    JSONArray jsonArray = response.getJSONArray("GetMeetingTypeResult");
                                    ArrayList<String> spinnerArray = new ArrayList<>();
                                    ArrayList<String> spinnerIDArray = new ArrayList<>();
                                    if (jsonArray.length() > 0) {
                                        for (int i = 0; i < jsonArray.length(); i++) {
                                            JSONObject explrObject = jsonArray.getJSONObject(i);
                                            String sm_supplier_name = explrObject.getString("Type");
                                            String SM_SUPPLIER_ID = explrObject.getString("Value");
                                            spinnerArray.add(sm_supplier_name);
                                            spinnerIDArray.add(SM_SUPPLIER_ID);
                                        }
                                    }
                                    ArrayAdapter spinnerArrayAdapter = new ArrayAdapter(getActivity(),
                                            android.R.layout.simple_spinner_dropdown_item,
                                            spinnerArray);
                                    spin_meeting_type.setAdapter(spinnerArrayAdapter);
                                    spin_meeting_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                                            // your code here
                                            meetingtype = spinnerIDArray.get(position).toString();

                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parentView) {
                                            // your code here
                                        }

                                    });
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                    Log.e("Error In", "" + ex.getMessage());
                                }

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Log.d("Error", "" + error.getMessage());
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("securityToken", shared.getString("EMPLOYEE_ID_FINAL", ""));
                        return params;
                    }


                    @Override
                    public String getBodyContentType() {
                        return "application/json";
                    }
                };

                int socketTimeout = 3000000;
                RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                jsonObjectRequest.setRetryPolicy(policy);
                requestQueue.add(jsonObjectRequest);
            } else {
                Utilities.showDialog(coordinatorLayout, ErrorConstants.NO_NETWORK);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getChargeType() {
        try {
            if (Utilities.isNetworkAvailable(getActivity())) {

                String url = Constants.IP_ADDRESS + "/SavvyMobileService.svc/GetChargesType";
                final JSONObject pm = new JSONObject();
                JSONObject params_final = new JSONObject();

                params_final.put("employeeId", shared.getString("EMPLOYEE_ID_FINAL", ""));


//              pm.put("objSendConveyanceRequestInfo", params_final);

                RequestQueue requestQueue = Volley.newRequestQueue(getContext());

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, params_final,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                int len = (String.valueOf(response)).length();

                                System.out.print("Array " + " Length = " + len + " Value = " + response.toString());
                                Log.e("getChargeType", " Length = " + len + " Value = " + response.toString());

                                try {
//                                    JSONArray jsonArray = new JSONArray(response);
                                    JSONArray jsonArray = response.getJSONArray("GetChargesTypeResult");
                                    ArrayList<String> spinnerArray = new ArrayList<>();
                                    ArrayList<String> spinnerIDArray = new ArrayList<>();
                                    if (jsonArray.length() > 0) {
                                        for (int i = 0; i < jsonArray.length(); i++) {
                                            JSONObject explrObject = jsonArray.getJSONObject(i);
                                            String sm_supplier_name = explrObject.getString("Type");
                                            String SM_SUPPLIER_ID = explrObject.getString("Value");
                                            spinnerArray.add(sm_supplier_name);
                                            spinnerIDArray.add(SM_SUPPLIER_ID);
                                        }
                                    }
                                    ArrayAdapter spinnerArrayAdapter = new ArrayAdapter(getActivity(),
                                            android.R.layout.simple_spinner_dropdown_item,
                                            spinnerArray);
                                    spin_charge_type.setAdapter(spinnerArrayAdapter);
                                    spin_charge_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                                            // your code here
                                            chargestype = spinnerIDArray.get(position).toString();

                                            //getCheckInCheckOutForButton();

                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parentView) {
                                            // your code here
                                        }

                                    });
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                    Log.e("Error In", "" + ex.getMessage());
                                }

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Log.d("Error", "" + error.getMessage());
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("securityToken", shared.getString("EMPLOYEE_ID_FINAL", ""));
                        return params;
                    }


                    @Override
                    public String getBodyContentType() {
                        return "application/json";
                    }
                };

                int socketTimeout = 3000000;
                RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                jsonObjectRequest.setRetryPolicy(policy);
                requestQueue.add(jsonObjectRequest);
            } else {
                Utilities.showDialog(coordinatorLayout, ErrorConstants.NO_NETWORK);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getCabType() {
        try {
            if (Utilities.isNetworkAvailable(getActivity())) {

                String url = Constants.IP_ADDRESS + "/SavvyMobileService.svc/GetCabType";
                final JSONObject pm = new JSONObject();
                JSONObject params_final = new JSONObject();

                params_final.put("employeeId", shared.getString("EMPLOYEE_ID_FINAL", ""));


//            pm.put("objSendConveyanceRequestInfo", params_final);

                RequestQueue requestQueue = Volley.newRequestQueue(getContext());

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, params_final,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                int len = (String.valueOf(response)).length();

                                System.out.print("GetCabType " + " Length = " + len + " Value = " + response.toString());
                                Log.e("getChargeType", " Length = " + len + " Value = " + response.toString());

                                try {
//                                    JSONArray jsonArray = new JSONArray(response);
                                    JSONArray jsonArray = response.getJSONArray("GetCabTypeResult");
                                    ArrayList<String> spinnerArray = new ArrayList<>();
                                    ArrayList<String> spinnerIDArray = new ArrayList<>();
                                    if (jsonArray.length() > 0) {
                                        for (int i = 0; i < jsonArray.length(); i++) {
                                            JSONObject explrObject = jsonArray.getJSONObject(i);
                                            String sm_supplier_name = explrObject.getString("Type");
                                            String SM_SUPPLIER_ID = explrObject.getString("Value");
                                            spinnerArray.add(sm_supplier_name);
                                            spinnerIDArray.add(SM_SUPPLIER_ID);
                                        }
                                    }
                                    ArrayAdapter spinnerArrayAdapter = new ArrayAdapter(getActivity(),
                                            android.R.layout.simple_spinner_dropdown_item,
                                            spinnerArray);
                                    spin_cab_type.setAdapter(spinnerArrayAdapter);
                                    spin_cab_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                                            // your code here
                                            cabtype_id = spinnerIDArray.get(position).toString();
                                            cabtype = spinnerArray.get(position).toString();

                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parentView) {
                                            // your code here
                                        }

                                    });

                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                    Log.e("Error In", "" + ex.getMessage());
                                }

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Log.d("Error", "" + error.getMessage());
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("securityToken", shared.getString("EMPLOYEE_ID_FINAL", ""));
                        return params;
                    }


                    @Override
                    public String getBodyContentType() {
                        return "application/json";
                    }
                };

                int socketTimeout = 3000000;
                RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                jsonObjectRequest.setRetryPolicy(policy);
                requestQueue.add(jsonObjectRequest);
            } else {
                Utilities.showDialog(coordinatorLayout, ErrorConstants.NO_NETWORK);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getDropDownType() {
        try {
            if (Utilities.isNetworkAvailable(getActivity())) {

                String url = Constants.IP_ADDRESS + "/SavvyMobileService.svc/GetDropDownType";
                final JSONObject pm = new JSONObject();
                JSONObject params_final = new JSONObject();

                params_final.put("employeeId", shared.getString("EMPLOYEE_ID_FINAL", ""));


//            pm.put("objSendConveyanceRequestInfo", params_final);

                RequestQueue requestQueue = Volley.newRequestQueue(getContext());

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, params_final,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                int len = (String.valueOf(response)).length();

                                System.out.print("GetCabType " + " Length = " + len + " Value = " + response.toString());
                                Log.e("getDropDownType", " Length = " + len + " Value = " + response.toString());

                                try {
//                                    JSONArray jsonArray = new JSONArray(response);
                                    JSONArray jsonArray = response.getJSONArray("GetDropDownTypeResult");
                                    ArrayList<String> spinnerArray = new ArrayList<>();
                                    ArrayList<String> spinnerIDArray = new ArrayList<>();
                                    if (jsonArray.length() > 0) {
                                        for (int i = 0; i < jsonArray.length(); i++) {
                                            JSONObject explrObject = jsonArray.getJSONObject(i);
                                            String sm_supplier_name = explrObject.getString("Type");
                                            String SM_SUPPLIER_ID = explrObject.getString("Value");
                                            spinnerArray.add(sm_supplier_name);
                                            spinnerIDArray.add(SM_SUPPLIER_ID);
                                        }
                                    }
                                    ArrayAdapter spinnerArrayAdapter = new ArrayAdapter(getActivity(),
                                            android.R.layout.simple_spinner_dropdown_item,
                                            spinnerArray);
                                    spin_dropdown_type.setAdapter(spinnerArrayAdapter);
                                    spin_dropdown_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                                            // your code here
                                            cabtmt = spinnerIDArray.get(position).toString();
                                            if (spinnerArray.get(position).toString().equals("Self")) {
                                                cab_upload_file_layout.setVisibility(View.VISIBLE);
                                                cab_amount_layout.setVisibility(View.VISIBLE);
                                            } else {
                                                cab_upload_file_layout.setVisibility(View.GONE);
                                                cab_amount_layout.setVisibility(View.GONE);
                                            }
                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parentView) {
                                            // your code here
                                        }

                                    });
                                    hotel_book_spinner.setAdapter(spinnerArrayAdapter);
                                    train_book_spinner.setAdapter(spinnerArrayAdapter);
                                    flight_book_spinner.setAdapter(spinnerArrayAdapter);

                                    hotel_book_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                                            // your code here
                                            hotelid = spinnerIDArray.get(position).toString();
                                            hotelbookby = spinnerArray.get(position).toString();
                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parentView) {
                                            // your code here
                                        }

                                    });
                                    train_book_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                                            // your code here
                                            trainid = spinnerIDArray.get(position).toString();
                                            trainbookby = spinnerArray.get(position).toString();

                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parentView) {
                                            // your code here
                                        }

                                    });
                                    flight_book_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                                            // your code here
                                            flightid = spinnerIDArray.get(position).toString();
                                            flightbookby = spinnerArray.get(position).toString();
                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parentView) {
                                            // your code here
                                        }

                                    });
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                    Log.e("Error In", "" + ex.getMessage());
                                }

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Log.d("Error", "" + error.getMessage());
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("securityToken", shared.getString("EMPLOYEE_ID_FINAL", ""));
                        return params;
                    }


                    @Override
                    public String getBodyContentType() {
                        return "application/json";
                    }
                };

                int socketTimeout = 3000000;
                RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                jsonObjectRequest.setRetryPolicy(policy);
                requestQueue.add(jsonObjectRequest);
            } else {
                Utilities.showDialog(coordinatorLayout, ErrorConstants.NO_NETWORK);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveAllDetails() {
        try {
            String Newfilemul = "";
            if (multiple_item_list.size() > 0)
                for (int i = 0; i < multiple_item_list.size(); i++) {
                    if (i == 0) {
                        Newfilemul = multiple_item_list.get(i).getFile_name();
                    } else {
                        Newfilemul = Newfilemul + "," + multiple_item_list.get(i).getFile_name();
                    }
                }
            if (Utilities.isNetworkAvailable(getActivity())) {
                ProgressDialog progressDialog = new ProgressDialog(getActivity());
                progressDialog.setMessage("Uploading...");
                progressDialog.setCancelable(true);
                progressDialog.show();
                String url = Constants.IP_ADDRESS + "/SavvyMobileService.svc/SaveCheckInOutDetails";
                Log.e("Save all data", "<><>" + url);
                JSONObject params_final = new JSONObject();

                params_final.put("employeeid", shared.getString("EMPLOYEE_ID_FINAL", ""));
                params_final.put("supplierid", supplierid);
                params_final.put("worktype", worktype);
                params_final.put("meetingtype", meetingtype);
                params_final.put("chargestype", chargestype);
                params_final.put("date", btn_InOutdate.getText().toString());
                params_final.put("newfilemul", Newfilemul);
                params_final.put("orgfilemul", Newfilemul);
                params_final.put("toll", edt_InOut_amount.getText().toString());
                params_final.put("hotelbookby", hotelbookby);
                params_final.put("hotelamt", hotelid);
                params_final.put("flightbookby", flightbookby);
                params_final.put("flightamt", flightid);
                params_final.put("trainbookby", trainbookby);
                params_final.put("trainamt", trainid);
                params_final.put("cabbookby", cabtype_id);
                params_final.put("cabamt", cabtmt);
                params_final.put("otheramt", "");
                params_final.put("newfileflight", "");
                params_final.put("newfiletrain", "");
                params_final.put("newfilehotel", "");
                params_final.put("newfilecab", "");
                params_final.put("newfileother", "");
                params_final.put("orgfileflight", "");
                params_final.put("orgfiletrain", "");
                params_final.put("orgfilehotel", "");
                params_final.put("orgfilecab", actualFileName);
                params_final.put("orgfileother", btn_otheruploadFile.getText().toString());
                params_final.put("remarks", edt_InOut_remarks.getText().toString());
                params_final.put("time", btn_od_to_time.getText().toString());
                params_final.put("cabtype", cabtype_id);

                Log.e("Save all data", "<><>" + params_final.toString());

                RequestQueue requestQueue = Volley.newRequestQueue(getContext());

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, params_final,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                int len = (String.valueOf(response)).length();

                                Log.e("Save all data", "<><>" + response.toString());
                                try {
                                    if (progressDialog != null) {
                                        progressDialog.dismiss();
                                    }
                                } catch (Exception e) {
                                }
                                Utilities.showDialog(coordinatorLayout, "Data Saved successfully!");
                                Toast.makeText(context, "Data Saved successfully!", Toast.LENGTH_SHORT).show();

                                //startActivity(new Intent(getActivity(), DashBoardActivity.class));
                                getCheckInCheckOutForButton();

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Log.d("Error", "" + error.getMessage());
                        try {
                            if (progressDialog != null) {
                                progressDialog.dismiss();
                            }
                        } catch (Exception e) {
                        }
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("securityToken", shared.getString("EMPLOYEE_ID_FINAL", ""));
                        return params;
                    }


                    @Override
                    public String getBodyContentType() {
                        return "application/json";
                    }
                };

                int socketTimeout = 3000000;
                RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                jsonObjectRequest.setRetryPolicy(policy);
                requestQueue.add(jsonObjectRequest);
            } else {
                Utilities.showDialog(coordinatorLayout, ErrorConstants.NO_NETWORK);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void getCheckInCheckOutForButton() {
        try {
            String Newfilemul = "";

            if (Utilities.isNetworkAvailable(getActivity())) {
                //ProgressDialog progressDialog = new ProgressDialog(getActivity());
                //progressDialog.setMessage("Uploading...");
                //progressDialog.setCancelable(true);
                //progressDialog.show();
                String url = Constants.IP_ADDRESS + "/SavvyMobileService.svc/GetCheckInCheckOutForButton";
                Log.e("Save all data", "<><>" + url);
                JSONObject params_final = new JSONObject();

                params_final.put("employeeId", shared.getString("EMPLOYEE_ID_FINAL", ""));
                params_final.put("supplierid", supplierid);
                params_final.put("worktype", "0");
                params_final.put("meetingtype", "0");
                params_final.put("chargestype", "0");
                params_final.put("date", btn_InOutdate.getText().toString());


                Log.e("Save all data", "<><>" + params_final.toString());

                RequestQueue requestQueue = Volley.newRequestQueue(getContext());

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, params_final,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                int len = (String.valueOf(response)).length();

                                Log.e("Save all data", "<><>" + response.toString());
                                try {
                                    //if (progressDialog != null) {
                                      //  progressDialog.dismiss();
                                        //JSONArray jsonArray = new JSONArray(response);
                                        JSONArray jsonArray = response.getJSONArray("GetCheckInCheckOutForButtonResult");
                                        Log.e("TAG", "activityResponseArray" + jsonArray.length());

                                        int length = jsonArray.length();
                                        if (jsonArray.length() > 0) {
                                            btn_submit.setText("Check Out");

                                            //btn_submit.setBackground(Drawable.createFromPath("@drawable/button_border_cancel"));
//                                            for (int i = 0; i < jsonArray.length(); i++) {

//                                            }
                                        }

                                    //}
                                } catch (Exception e) {
                                }
                                //Utilities.showDialog(coordinatorLayout, "Data fetched successfully!");
                                //Toast.makeText(context, "Data fetched successfully!", Toast.LENGTH_SHORT).show();

                                //startActivity(new Intent(getActivity(), DashBoardActivity.class));

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Log.d("Error", "" + error.getMessage());
                        try {
                            if (progressDialog != null) {
                                progressDialog.dismiss();
                            }
                        } catch (Exception e) {
                        }
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("securityToken", shared.getString("EMPLOYEE_ID_FINAL", ""));
                        return params;
                    }


                    @Override
                    public String getBodyContentType() {
                        return "application/json";
                    }
                };

                int socketTimeout = 3000000;
                RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                jsonObjectRequest.setRetryPolicy(policy);
                requestQueue.add(jsonObjectRequest);
            } else {
                Utilities.showDialog(coordinatorLayout, ErrorConstants.NO_NETWORK);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //
//    private class GetOvertimeReason extends AsyncTask<String, String, String> {
//        private ProgressDialog pDialog;
//
//        @Override
//        protected void onPreExecute() {
//            // Things to be done before execution of long running operation. For
//            // example showing ProgessDialog
//            pDialog = new ProgressDialog(getActivity());
//            pDialog.setMessage("Please wait...");
//            pDialog.setIndeterminate(false);
//            pDialog.setCancelable(true);
//            pDialog.show();
//
//        }
//
//        @Override
//        protected String doInBackground(String... params) {
//            //publishProgress("Sleeping..."); // Calls onProgressUpdate()
//
//            try {
//
//                //String LOGIN_URL = "http://savvyshippingsoftware.com/SavvyMobile/SavvyMobileService.svc//GetCurrentDateTime";
//                String GETREQUESTSTATUS_URL = Constants.IP_ADDRESS + "/SavvyMobileService.svc/GetODTypeMaster/1";
//
//                System.out.println("ATTENDANCE_URL====" + GETREQUESTSTATUS_URL);
//                JSONParser jParser = new JSONParser(getActivity()); // get JSON data from URL JSONArray json = jParser.getJSONFromUrl(url);
//                String json = jParser.makeHttpRequest(
//                        GETREQUESTSTATUS_URL, "GET");
//
//                if (json != null) {
//                    Log.d("JSON result", json.toString());
//
//                    return json;
//                }
//
//
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//
//            return null;
//        }
//
//
//        @Override
//        protected void onPostExecute(String result) {
//            // execution of result of Long time consuming operation
//            //finalResult.setText(result);
//            if (pDialog != null && pDialog.isShowing()) {
//                pDialog.dismiss();
//                try {
//                    HashMap<String, String> requestStatusmap;
//                    // ArrayList<String> requestArray;
//                    JSONArray jsonArray = new JSONArray(result);
//                    System.out.println("jsonArray===" + jsonArray);
//                    //requestArray=new ArrayList<String>();
//                    if (jsonArray.length() > 0) {
//                        for (int i = 0; i < jsonArray.length(); i++) {
//                            requestStatusmap = new HashMap<String, String>();
//                            JSONObject explrObject = jsonArray.getJSONObject(i);
//                            String key = explrObject.getString("ODMasterId");
//                            String value = explrObject.getString("ODType");
//                            // requestArray.add(value);
//                            requestStatusmap.put("KEY", key);
//                            requestStatusmap.put("VALUE", value);
//
//                            arlRequestStatusData.add(requestStatusmap);
//                        }
//                        System.out.println("Array===" + arlRequestStatusData);
//
//                        customspinnerAdapter = new CustomSpinnerAdapter(getActivity(), arlRequestStatusData);
//                        spin_reason_od.setAdapter(customspinnerAdapter);
//
//                    } else {
//                        Utilities.showDialog(coordinatorLayout, ErrorConstants.DATA_ERROR);
//                        System.out.println("Data not getting on server side");
//                    }
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//
//
//        @Override
//        protected void onProgressUpdate(String... text) {
//            // finalResult.setText(text[0]);
//            // Things to be done while execution of long running operation is in
//            // progress. For example updating ProgessDialog
//        }
//    }
    private void buildPart(DataOutputStream dataOutputStream, byte[] fileData, String fileName) throws IOException {
        dataOutputStream.writeBytes(twoHyphens + boundary + lineEnd);
        dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\"; filename=\"" + fileName + "\"" + lineEnd);
        dataOutputStream.writeBytes(lineEnd);
        ByteArrayInputStream fileInputStream = new ByteArrayInputStream(fileData);
        int bytesAvailable = fileInputStream.available();

        int maxBufferSize = 1024 * 1024;
        int bufferSize = Math.min(bytesAvailable, maxBufferSize);
        byte[] buffer = new byte[bufferSize];

        int bytesRead = fileInputStream.read(buffer, 0, bufferSize);
        while (bytesRead > 0) {
            dataOutputStream.write(buffer, 0, bufferSize);
            bytesAvailable = fileInputStream.available();
            bufferSize = Math.min(bytesAvailable, maxBufferSize);
            bytesRead = fileInputStream.read(buffer, 0, bufferSize);
        }

        dataOutputStream.writeBytes(lineEnd);
    }

    public void imageProcessRequest(byte[] fileData1, String filename) {
        //  String IMG_URL = Constants.IP_ADDRESS + "/MobileFileUpload.ashx?empCode=" + employeeId;
        String IMG_URL = Constants.IP_ADDRESS + "/MobileFileUpload.ashx?Type=TravelCheckInOut";

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(bos);

        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Uploading...");
        progressDialog.setCancelable(true);
        progressDialog.show();

        try {
            buildPart(dos, fileData1, filename);
            dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
            multipartBody = bos.toByteArray();
            MultipartRequest multipartRequest = new MultipartRequest(IMG_URL, null, mimeType, multipartBody, new Response.Listener<NetworkResponse>() {
                @Override
                public void onResponse(NetworkResponse response) {
                    try {
                        progressDialog.dismiss();
                        String result = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                        List<String> list = Arrays.asList(result.split(","));
                        // int value = Integer.valueOf(list.get(0));
                        /* if (value == 1) {*/
                        Utilities.showDialog(coordinatorLayout, "Image uploaded Successfully");
                        /*}*/
                        actualFileName = list.get(1);
                        if (check_click.equals("multi")) {
                            // ml.callback(actualFileName);
                            FileNameModel fileNameModel = new FileNameModel();
                            fileNameModel.setFile_name(actualFileName);
                            fileNameModel.setPosition(Position);
                            multiple_item_list.set(Position, fileNameModel);
                            addMultipleItem();
                        } else if (check_click.equals("other")) {
                            // ml.callback(actualFileName);
                            btn_otheruploadFile.setText(actualFileName);
                        } else {
                            btn_cabuploadFile.setText(actualFileName);
                        }

                        Log.e("actualFileName", "<><>" + actualFileName);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.e("Exception>>", "<><>" + e.toString());
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.dismiss();
                    Toast.makeText(getActivity(), "Upload failed!\r\n" + error.toString(), Toast.LENGTH_SHORT).show();
                }
            }, new MultipartRequest.FileUploadListener() {
                @Override
                public void onUpdateProgress(int percentage, long totalSize) {
                }
            });
            int socketTimeout = 3000000;
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            multipartRequest.setRetryPolicy(policy);
            VolleySingleton.getInstance(getActivity()).addToRequestQueue(multipartRequest);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void addMultipleItem() {
        if (multiple_item_list.size() == 1) {
            click_handle = true;
        }
        AddMultipleItemsAdapter side_rv_adapter = new AddMultipleItemsAdapter(getActivity(), multiple_item_list);
        add_multiple_file.setLayoutManager(new LinearLayoutManager(getActivity(), RecyclerView.VERTICAL, false));
        add_multiple_file.setItemAnimator(new DefaultItemAnimator());
        /*  cardView.scheduleLayoutAnimation();*/
        add_multiple_file.setNestedScrollingEnabled(false);
        add_multiple_file.setAdapter(side_rv_adapter);
        add_multiple_file.setItemViewCacheSize(multiple_item_list.size());
        add_multiple_file.setHasFixedSize(true);
        side_rv_adapter.notifyDataSetChanged();
        add_multiple_file.addOnItemTouchListener(new RecyclerTouchListener(getActivity(), add_multiple_file, new ClickListener() {
            @Override
            public void onClick(View view, int position) {
                try {
                    if (click_handle) {
                        click_handle = false;
                        Log.e("Exception", "<><>");
                        check_click = "multi";
                        Position = position;
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("*/*");
                        startActivityForResult(intent, 999);
                    }
                } catch (Exception e) {
                    Log.e("Exception", "<><>" + e.toString());
                }
            }

            @Override
            public void onLongClick(View view, int position) {
            }
        }));
    }

    public void getFile(int position, Context context1, FilePathListener filePathListener) {
        try {
            Activity act = (Activity) context1;
            ml = filePathListener;
            check_click = "multi";
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*");
            ((Activity) context1).startActivityForResult(intent, 999);
        } catch (Exception e) {
            Log.e("Exception", "<><>" + e.toString());
        }
    }

}
