package com.savvy.hrmsnewapp.model;

/**
 * Created by AM00347646 on 30-08-2016.
 */
public class RootMenuOptionModel {


    public MenuOptionModel getJson_data() {
        return json_data;
    }

    public void setJson_data(MenuOptionModel json_data) {
        this.json_data = json_data;
    }

    public MenuOptionModel json_data;
}
