package com.savvy.hrmsnewapp.model;

/**
 * Created by Amulya on 8/15/2016.
 */
public class TopicModel {

    public String getTopic_id() {
        return topic_id;
    }

    public void setTopic_id(String topic_id) {
        this.topic_id = topic_id;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getPosted_date() {
        return posted_date;
    }

    public void setPosted_date(String posted_date) {
        this.posted_date = posted_date;
    }

    public String getPosted_day() {
        return posted_day;
    }

    public void setPosted_day(String posted_day) {
        this.posted_day = posted_day;
    }

    public String getTopic_name() {
        return topic_name;
    }

    public void setTopic_name(String topic_name) {
        this.topic_name = topic_name;
    }

    public String getTopic_status() {
        return topic_status;
    }

    public void setTopic_status(String topic_status) {
        this.topic_status = topic_status;
    }

    public String getTime_stamp() {
        return time_stamp;
    }

    public void setTime_stamp(String time_stamp) {
        this.time_stamp = time_stamp;
    }

    public String getAttachement_name() {
        return attachement_name;
    }

    public void setAttachement_name(String attachement_name) {
        this.attachement_name = attachement_name;
    }

    public String getAttachement_type() {
        return attachement_type;
    }

    public void setAttachement_type(String attachement_type) {
        this.attachement_type = attachement_type;
    }

    public String getAttachement_dwn_link() {
        return attachement_dwn_link;
    }

    public void setAttachement_dwn_link(String attachement_dwn_link) {
        this.attachement_dwn_link = attachement_dwn_link;
    }

    public String getSubject_color() {
        return subject_color;
    }

    public void setSubject_color(String subject_color) {
        this.subject_color = subject_color;
    }

    public String topic_id;
    public String subject;
    public String posted_date;
    public String posted_day;
    public String topic_name;
    public String topic_status;
    public String time_stamp;
    public String attachement_name;
    public String attachement_type;
    public String attachement_dwn_link;
    public String subject_color;
}
