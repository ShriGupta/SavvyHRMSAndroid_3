package com.savvy.hrmsnewapp.model;

/**
 * Created by Amulya on 7/16/2016.
 */
public class RootUploadImageModel {

    public UploadImageModel getJson_data() {
        return json_data;
    }

    public void setJson_data(UploadImageModel json_data) {
        this.json_data = json_data;
    }

    public UploadImageModel json_data;
}
