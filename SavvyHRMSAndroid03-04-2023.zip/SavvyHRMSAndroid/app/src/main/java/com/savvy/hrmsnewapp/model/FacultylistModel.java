package com.savvy.hrmsnewapp.model;

/**
 * Created by Hari Om on 8/15/2016.
 */
public class FacultylistModel {

    public String getFaculty_id() {
        return faculty_id;
    }

    public void setFaculty_id(String faculty_id) {
        this.faculty_id = faculty_id;
    }

    public String getFaculty_name() {
        return faculty_name;
    }

    public void setFaculty_name(String faculty_name) {
        this.faculty_name = faculty_name;
    }

    public String faculty_id;
    public String faculty_name;

   // public String mailsender_image_url;
}
