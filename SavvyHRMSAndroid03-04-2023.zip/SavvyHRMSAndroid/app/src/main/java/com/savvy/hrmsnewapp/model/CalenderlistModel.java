package com.savvy.hrmsnewapp.model;

/**
 * Created by Hari Om on 8/8/2016.
 */
public class CalenderlistModel {


    public String getFaculty_id() {
        return faculty_id;
    }

    public void setFaculty_id(String faculty_id) {
        this.faculty_id = faculty_id;
    }

    public String getFaculty_name() {
        return faculty_name;
    }

    public void setFaculty_name(String faculty_name) {
        this.faculty_name = faculty_name;
    }

    public String getFaculty_subject() {
        return faculty_subject;
    }

    public void setFaculty_subject(String faculty_subject) {
        this.faculty_subject = faculty_subject;
    }

    public String getFaculty_photo() {
        return faculty_photo;
    }

    public void setFaculty_photo(String faculty_photo) {
        this.faculty_photo = faculty_photo;
    }

    public String getFaculty_timing() {
        return faculty_timing;
    }

    public void setFaculty_timing(String faculty_timing) {
        this.faculty_timing = faculty_timing;
    }

    public String faculty_id;
    public String faculty_name;
    public String faculty_subject;
    public String faculty_photo;
    public String faculty_timing;


}
